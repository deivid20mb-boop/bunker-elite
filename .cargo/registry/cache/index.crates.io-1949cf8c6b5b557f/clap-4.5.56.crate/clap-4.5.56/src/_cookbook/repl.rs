//! # Example: Command REPL (Builder API)
//!
//! ```rust
#![doc = include_str!("../../examples/repl.rs")]
//! ```
