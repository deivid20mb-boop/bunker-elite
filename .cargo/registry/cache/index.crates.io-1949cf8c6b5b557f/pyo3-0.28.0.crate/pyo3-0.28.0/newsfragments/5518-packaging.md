Add 3.15 to CI for preliminary testing
